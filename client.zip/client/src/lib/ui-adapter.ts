// UI Adapter to convert API savings cards to UI component format

// types the API returns
export type ApiSavingsCard = {
  type: 'rate-reprice' | 'points-breakeven' | 'origination-fee' | 'title-shopping' | 'mi-optimization';
  title: string;
  impactMonthly: number;   // $/mo (>= 0)
  impactHorizon: number;   // $ one-time or horizon total (>= 0)
  script: string;
  measured?: Record<string, unknown>;
  target?: Record<string, unknown>;
};

// types your component expects
export type UiSavingsCard = {
  id: string;
  type: ApiSavingsCard['type'];
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  impact: {
    isOneTime: boolean;
    monthlyAmount: number; // $/mo when not one-time
    totalAmount: number;   // $ total when one-time
  };
  details: {
    current: Record<string, unknown>;
    target: Record<string, unknown>;
  };
  rationale: string;
  script: string;
};

// simple priority rule-of-thumb
function computePriority(c: ApiSavingsCard): 'high' | 'medium' | 'low' {
  if (c.type === 'rate-reprice' && c.impactMonthly >= 100) return 'high';
  if (c.impactHorizon >= 1000) return 'high';
  if (c.impactMonthly >= 40 || c.impactHorizon >= 500) return 'medium';
  return 'low';
}

// Generate description and rationale based on card type
function generateDescription(c: ApiSavingsCard): string {
  const descriptions: Record<string, string> = {
    'rate-reprice': 'Negotiate a lower interest rate based on current market conditions',
    'points-breakeven': 'Optimize discount points to reduce your monthly payment',
    'origination-fee': 'Reduce or eliminate excessive origination fees',
    'title-shopping': 'Shop for competitive title insurance rates',
    'mi-optimization': 'Optimize mortgage insurance costs and requirements'
  };
  return descriptions[c.type] || 'Potential savings opportunity identified';
}

function generateRationale(c: ApiSavingsCard): string {
  const rationales: Record<string, string> = {
    'rate-reprice': 'Your current rate appears higher than market rates for your profile. Requesting a rate reduction could significantly lower your monthly payments.',
    'points-breakeven': 'The cost of discount points may be justified by the monthly savings over your planned ownership period.',
    'origination-fee': 'Your origination fees exceed typical market rates. These fees are often negotiable.',
    'title-shopping': 'Title insurance rates can vary significantly between providers. Shopping around often yields substantial savings.',
    'mi-optimization': 'Your mortgage insurance costs may be optimizable through different loan structures or providers.'
  };
  return rationales[c.type] || 'This opportunity has been identified through our analysis of your loan terms.';
}

// map API card -> UI card the component wants
export function toUiSavingsCard(c: ApiSavingsCard, horizonYears: number): UiSavingsCard {
  const isOneTime =
    c.type === 'origination-fee' ||
    c.type === 'title-shopping' ||
    c.type === 'mi-optimization' ||
    (c.impactMonthly <= 0 && c.impactHorizon > 0);

  return {
    id: `${c.type}-${Date.now()}`, // Generate unique ID
    type: c.type,
    title: c.title,
    description: generateDescription(c),
    priority: computePriority(c),
    impact: {
      isOneTime,
      monthlyAmount: Math.max(0, c.impactMonthly),
      // if card is "monthly", your component shows monthly; if "one-time", show total
      // use API's horizon number directly for one-time cards
      totalAmount: Math.max(0, c.impactHorizon),
    },
    details: {
      current: c.measured || {},
      target: c.target || {}
    },
    rationale: generateRationale(c),
    script: c.script,
  };
}