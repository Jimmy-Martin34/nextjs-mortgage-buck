import { apiRequest } from "./queryClient";

export interface PresignResponse {
  uploadUrl: string;
  fileKey: string;
  expiresIn: number;
}

export interface SubmissionResponse {
  id: string;
}

export interface AnalysisResponse {
  verdict: {
    monthlyOverpay: number;
    fiveYearSavings: number;
    confidence: number;
  };
  assumptions: {
    creditBand: string;
    ltv: number;
    occupancy: string;
    state: string;
    county: string;
    horizonYears: number;
    parRate: number;
    propertyValue?: number;
  };
  savings: Array<{
    id: string;
    title: string;
    description: string;
    type: string;
    impact: {
      monthlyAmount: number;
      totalAmount: number;
      isOneTime: boolean;
    };
    details: any;
    rationale: string;
    script: string;
    priority: 'high' | 'medium' | 'low';
  }>;
  flags: Array<{
    code: string;
    message: string;
  }>;
}

export interface ChatResponse {
  response: string;
}

export interface AdminStatsResponse {
  totalSubmissions: number;
  successRate: number;
  avgProcessingTime: string;
  avgSavings: string;
}

export const api = {
  // File upload
  async getPresignedUrl(fileName: string, fileType: string, fileSize: number): Promise<PresignResponse> {
    const response = await apiRequest('POST', '/api/presign', {
      fileName,
      fileType,
      fileSize,
    });
    return response.json();
  },

  async uploadToS3(uploadUrl: string, file: File): Promise<void> {
    const response = await fetch(uploadUrl, {
      method: 'PUT',
      body: file,
      headers: {
        'Content-Type': file.type,
      },
    });

    if (!response.ok) {
      throw new Error('Upload failed');
    }
  },

  // Submissions
  async createSubmission(data: {
    email: string;
    fileKey: string;
    docType?: string;
    state?: string;
    county?: string;
    lenderName?: string;
  }): Promise<SubmissionResponse> {
    const response = await apiRequest('POST', '/api/submissions', data);
    return response.json();
  },

  async getSubmission(id: string) {
    const response = await apiRequest('GET', `/api/submissions/${id}`);
    return response.json();
  },

  async listSubmissions(limit = 50, offset = 0) {
    const response = await apiRequest('GET', `/api/submissions?limit=${limit}&offset=${offset}`);
    return response.json();
  },

  // Analysis
  async analyzeSubmission(submissionId: string, overrides?: any): Promise<AnalysisResponse> {
    const response = await apiRequest('POST', '/api/analyze', {
      submissionId,
      overrides,
    });
    return response.json();
  },

  async getAnalysis(submissionId: string): Promise<AnalysisResponse> {
    const response = await apiRequest('GET', `/api/analyze/${submissionId}`);
    return response.json();
  },

  // Chat
  async sendChatMessage(submissionId: string, message: string): Promise<ChatResponse> {
    const response = await apiRequest('POST', '/api/chat', {
      submissionId,
      message,
    });
    return response.json();
  },

  // Admin
  async adminLogin(username: string, password: string) {
    const response = await apiRequest('POST', '/api/auth/login', {
      username,
      password,
    });
    return response.json();
  },

  async getAdminStats(): Promise<AdminStatsResponse> {
    const token = localStorage.getItem('adminToken');
    const response = await fetch('/api/admin/stats', {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch stats');
    }

    return response.json();
  },

  async getFilePreview(submissionId: string) {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`/api/files/${submissionId}/preview`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to get file preview');
    }

    return response.json();
  },

  // Helper for complete upload flow
  async uploadFile(file: File, email: string = 'user@example.com'): Promise<SubmissionResponse> {
    // Step 1: Get presigned URL
    const presignData = await this.getPresignedUrl(file.name, file.type, file.size);
    
    // Step 2: Upload to S3
    await this.uploadToS3(presignData.uploadUrl, file);
    
    // Step 3: Create submission
    return this.createSubmission({
      email,
      fileKey: presignData.fileKey,
    });
  },
};
