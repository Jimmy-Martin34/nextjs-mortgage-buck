import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import ResultsDisplay from "@/components/ResultsDisplay";
import AssumptionChips from "@/components/AssumptionChips";
import SavingsCard from "@/components/SavingsCard";
import ChatInterface from "@/components/ChatInterface";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toUiSavingsCard, type ApiSavingsCard } from "@/lib/ui-adapter";

export default function Results() {
  const { submissionId } = useParams();
  const [showChat, setShowChat] = useState(false);

  const { data: analysis, isLoading, error } = useQuery({
    queryKey: ['/api/analyze', submissionId],
    enabled: !!submissionId,
  });

  // Type guard to ensure analysis has the expected shape
  const hasValidAnalysis = analysis && 
    typeof analysis === 'object' && 
    'verdict' in analysis && 
    'assumptions' in analysis && 
    'savings' in analysis &&
    Array.isArray(analysis.savings);

  const { data: submission } = useQuery({
    queryKey: ['/api/submissions', submissionId],
    enabled: !!submissionId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Card className="mb-8">
            <CardContent className="p-6">
              <Skeleton className="h-8 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/2" />
            </CardContent>
          </Card>
          <div className="grid gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-1/3 mb-4" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-2/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error || !hasValidAnalysis) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card>
          <CardContent className="p-6 text-center">
            <div className="flex justify-center mb-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
            <h2 className="text-xl font-semibold mb-2">Processing Your Document</h2>
            <p className="text-muted-foreground mb-4">
              We're analyzing your mortgage document and calculating savings opportunities. This usually takes 30-60 seconds.
            </p>
            <div className="flex flex-col gap-2 text-sm text-muted-foreground mb-4">
              <div className="flex items-center justify-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                <span>Extracting loan terms and fees...</span>
              </div>
              <div className="flex items-center justify-center gap-2">
                <div className="w-2 h-2 bg-muted rounded-full"></div>
                <span>Analyzing market rates...</span>
              </div>
              <div className="flex items-center justify-center gap-2">
                <div className="w-2 h-2 bg-muted rounded-full"></div>
                <span>Calculating savings opportunities...</span>
              </div>
            </div>
            <Button onClick={() => window.location.reload()}>
              Refresh
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header with navigation */}
      <header className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-calculator text-primary-foreground text-sm"></i>
              </div>
              <span className="text-xl font-semibold text-foreground">Mortgage Analyzer</span>
            </div>
            
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowChat(!showChat)}
                data-testid="button-toggle-chat"
              >
                <i className="fas fa-comments mr-2"></i>
                Chat Assistant
              </Button>
              <Button 
                onClick={() => window.location.href = '/'}
                data-testid="button-new-analysis"
              >
                New Analysis
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Results Header */}
      <section className="bg-gradient-to-r from-success/10 to-primary/10 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <ResultsDisplay verdict={(analysis as any).verdict} />
          <AssumptionChips 
            assumptions={(analysis as any).assumptions}
            submissionId={submissionId!}
          />
        </div>
      </section>

      {/* Savings Cards */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-foreground mb-2">Savings Opportunities</h2>
            <p className="text-muted-foreground">Here are the specific ways you can reduce your mortgage costs</p>
          </div>
          
          <div className="grid gap-6 mb-6">
            {(analysis as any).savings.map((apiCard: ApiSavingsCard, index: number) => {
              const uiCard = toUiSavingsCard(apiCard, (analysis as any).assumptions?.horizonYears || 5);
              return <SavingsCard key={index} savings={uiCard} />;
            })}
          </div>

          {(analysis as any).savings.length === 0 && (
            <Card>
              <CardContent className="p-6 text-center">
                <i className="fas fa-check-circle text-success text-2xl mb-4"></i>
                <h3 className="text-lg font-semibold mb-2">Great News!</h3>
                <p className="text-muted-foreground">
                  Your loan terms appear to be competitive. We didn't find any significant savings opportunities.
                </p>
              </CardContent>
            </Card>
          )}

          {/* Action Summary */}
          {(analysis as any).savings.length > 0 && (
            <Card className="bg-gradient-to-r from-success/5 to-primary/5">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center">
                  <i className="fas fa-bullseye text-primary mr-2"></i>
                  Next Steps
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-foreground mb-2">Immediate Actions</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-center gap-2">
                        <i className="fas fa-check-circle text-success"></i>
                        Email rate comparison to your loan officer
                      </li>
                      <li className="flex items-center gap-2">
                        <i className="fas fa-check-circle text-success"></i>
                        Request fee breakdown justification
                      </li>
                      <li className="flex items-center gap-2">
                        <i className="fas fa-check-circle text-success"></i>
                        Ask for no-points rate option
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground mb-2">If No Response</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-center gap-2">
                        <i className="fas fa-search text-primary"></i>
                        Shop with 2-3 other lenders
                      </li>
                      <li className="flex items-center gap-2">
                        <i className="fas fa-calculator text-primary"></i>
                        Get competing Loan Estimates
                      </li>
                      <li className="flex items-center gap-2">
                        <i className="fas fa-handshake text-primary"></i>
                        Negotiate using best offer
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </section>

      {/* Chat Interface */}
      {showChat && submissionId && (
        <ChatInterface 
          submissionId={submissionId}
          onClose={() => setShowChat(false)}
        />
      )}
    </div>
  );
}
