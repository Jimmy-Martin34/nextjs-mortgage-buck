import { useState } from "react";
import { useLocation } from "wouter";
import Upload from "@/components/Upload";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Home() {
  const [, setLocation] = useLocation();
  const [showAdminLogin, setShowAdminLogin] = useState(false);

  const features = [
    {
      icon: "fas fa-percentage",
      title: "Rate Analysis",
      description: "Compare your quoted rate against market rates for your credit profile and loan details.",
    },
    {
      icon: "fas fa-coins",
      title: "Points Optimization", 
      description: "Calculate if buying points makes sense based on your time horizon and breakeven analysis.",
    },
    {
      icon: "fas fa-receipt",
      title: "Fee Review",
      description: "Identify excessive origination, title, and settlement fees with regional benchmarks.",
    },
    {
      icon: "fas fa-shield-alt",
      title: "MI Optimization",
      description: "Compare monthly vs single-premium MI options and identify removal opportunities.",
    },
    {
      icon: "fas fa-comments",
      title: "Negotiation Scripts",
      description: "Get copy-paste scripts to negotiate better terms with your lender.",
    },
    {
      icon: "fas fa-chart-line",
      title: "Impact Calculator",
      description: "See exact monthly and 5-year savings for each optimization opportunity.",
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-calculator text-primary-foreground text-sm"></i>
              </div>
              <span className="text-xl font-semibold text-foreground">Mortgage Analyzer</span>
            </div>
            
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors">Features</a>
              <a href="#how-it-works" className="text-muted-foreground hover:text-foreground transition-colors">How It Works</a>
              <a href="#security" className="text-muted-foreground hover:text-foreground transition-colors">Security</a>
              <Button 
                onClick={() => setLocation('/admin')}
                data-testid="button-admin-login"
              >
                Admin Login
              </Button>
            </nav>
            
            <button className="md:hidden text-muted-foreground">
              <i className="fas fa-bars text-lg"></i>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
            Stop Overpaying on Your 
            <span className="text-primary"> Mortgage</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Upload your Loan Estimate or Closing Disclosure and get instant analysis showing exactly where you're overpaying and how to fix it.
          </p>
          
          {/* Trust Indicators */}
          <div className="flex flex-wrap justify-center items-center gap-6 mb-12 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <i className="fas fa-shield-alt text-success"></i>
              <span>Bank-level security</span>
            </div>
            <div className="flex items-center gap-2">
              <i className="fas fa-clock text-primary"></i>
              <span>Results in 15 seconds</span>
            </div>
            <div className="flex items-center gap-2">
              <i className="fas fa-file-pdf text-warning"></i>
              <span>No email required</span>
            </div>
          </div>
        </div>
      </section>

      {/* Upload Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-secondary/50">
        <div className="max-w-2xl mx-auto">
          <Upload />
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4">How We Help You Save</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our analyzer identifies specific areas where you might be overpaying and provides actionable solutions
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <i className={`${feature.icon} text-primary text-xl`}></i>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
