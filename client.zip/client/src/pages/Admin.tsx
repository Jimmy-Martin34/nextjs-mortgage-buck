import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import AdminGuard from "@/components/AdminGuard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

export default function Admin() {
  const { toast } = useToast();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/admin/stats'],
    enabled: !!localStorage.getItem('adminToken'),
  });

  const { data: submissions, isLoading: submissionsLoading } = useQuery({
    queryKey: ['/api/submissions'],
    enabled: !!localStorage.getItem('adminToken'),
  });

  const previewMutation = useMutation({
    mutationFn: async (submissionId: string) => {
      const token = localStorage.getItem('adminToken');
      const response = await fetch(`/api/files/${submissionId}/preview`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!response.ok) throw new Error('Failed to get preview URL');
      return response.json();
    },
    onSuccess: (data) => {
      window.open(data.url, '_blank');
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate file preview",
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    window.location.href = '/';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: "default" | "secondary" | "destructive" | "outline" } = {
      received: "outline",
      extracting: "secondary", 
      extracted: "secondary",
      analyzed: "default",
      failed: "destructive"
    };
    return <Badge variant={variants[status] || "outline"}>{status}</Badge>;
  };

  return (
    <AdminGuard>
      <div className="min-h-screen bg-muted/30">
        {/* Admin Header */}
        <header className="bg-card border-b border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <i className="fas fa-cog text-primary-foreground text-sm"></i>
                </div>
                <span className="text-xl font-semibold text-foreground">Admin Dashboard</span>
              </div>
              
              <div className="flex items-center space-x-4">
                <span className="text-sm text-muted-foreground">Welcome back, Admin</span>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={handleLogout}
                  data-testid="button-logout"
                >
                  <i className="fas fa-sign-out-alt"></i>
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {statsLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <Skeleton className="h-4 w-1/2 mb-2" />
                    <Skeleton className="h-8 w-1/3 mb-4" />
                    <Skeleton className="h-3 w-2/3" />
                  </CardContent>
                </Card>
              ))
            ) : (
              <>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Total Submissions</p>
                        <p className="text-2xl font-bold text-foreground">{stats?.totalSubmissions || 0}</p>
                      </div>
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-file-upload text-primary text-xl"></i>
                      </div>
                    </div>
                    <div className="mt-4 flex items-center text-sm">
                      <span className="text-success font-medium">+12%</span>
                      <span className="text-muted-foreground ml-1">vs last month</span>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Success Rate</p>
                        <p className="text-2xl font-bold text-foreground">{stats?.successRate || 0}%</p>
                      </div>
                      <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-check-circle text-success text-xl"></i>
                      </div>
                    </div>
                    <div className="mt-4 flex items-center text-sm">
                      <span className="text-success font-medium">+0.3%</span>
                      <span className="text-muted-foreground ml-1">vs last month</span>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Avg Processing Time</p>
                        <p className="text-2xl font-bold text-foreground">{stats?.avgProcessingTime || '0s'}</p>
                      </div>
                      <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-clock text-warning text-xl"></i>
                      </div>
                    </div>
                    <div className="mt-4 flex items-center text-sm">
                      <span className="text-success font-medium">-1.2s</span>
                      <span className="text-muted-foreground ml-1">vs last month</span>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Avg Savings Found</p>
                        <p className="text-2xl font-bold text-foreground">{stats?.avgSavings || '$0/mo'}</p>
                      </div>
                      <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-dollar-sign text-success text-xl"></i>
                      </div>
                    </div>
                    <div className="mt-4 flex items-center text-sm">
                      <span className="text-success font-medium">+$23</span>
                      <span className="text-muted-foreground ml-1">vs last month</span>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </div>
          
          {/* Recent Submissions Table */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Submissions</CardTitle>
                <div className="flex gap-3">
                  <Button variant="outline" size="sm">
                    <i className="fas fa-filter mr-1"></i>Filter
                  </Button>
                  <Button variant="outline" size="sm">
                    <i className="fas fa-download mr-1"></i>Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {submissionsLoading ? (
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Submission ID</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Doc Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {submissions?.map((submission: any) => (
                      <TableRow key={submission.id}>
                        <TableCell className="font-mono text-sm">{submission.id.slice(0, 8)}</TableCell>
                        <TableCell>{submission.email}</TableCell>
                        <TableCell>
                          {submission.docType ? (
                            <Badge variant="outline">{submission.docType}</Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>{getStatusBadge(submission.status)}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(submission.createdAt)}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => window.location.href = `/results/${submission.id}`}
                              data-testid={`button-view-${submission.id}`}
                            >
                              <i className="fas fa-eye"></i>
                            </Button>
                            <Button
                              variant="ghost" 
                              size="sm"
                              onClick={() => previewMutation.mutate(submission.id)}
                              disabled={previewMutation.isPending}
                              data-testid={`button-preview-${submission.id}`}
                            >
                              <i className="fas fa-download"></i>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {submissions?.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          No submissions found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </AdminGuard>
  );
}
