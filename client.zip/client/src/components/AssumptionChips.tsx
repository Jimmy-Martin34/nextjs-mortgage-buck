import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface AssumptionChipsProps {
  assumptions: {
    creditBand: string;
    ltv: number;
    occupancy: string;
    state: string;
    county: string;
    horizonYears: number;
    parRate: number;
    propertyValue?: number;
  };
  submissionId: string;
}

export default function AssumptionChips({ assumptions, submissionId }: AssumptionChipsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditingOpen, setIsEditingOpen] = useState(false);
  const [editedAssumptions, setEditedAssumptions] = useState(assumptions);

  const reanalyzeMutation = useMutation({
    mutationFn: async (overrides: any) => {
      const response = await apiRequest('POST', '/api/analyze', {
        submissionId,
        overrides,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/analyze', submissionId] });
      setIsEditingOpen(false);
      toast({
        title: "Analysis Updated",
        description: "Your savings analysis has been recalculated with the new assumptions.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update analysis. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleReanalyze = () => {
    const changes: any = {};
    
    if (editedAssumptions.creditBand !== assumptions.creditBand) {
      changes.creditBand = editedAssumptions.creditBand;
    }
    if (editedAssumptions.ltv !== assumptions.ltv) {
      changes.ltv = editedAssumptions.ltv;
    }
    if (editedAssumptions.occupancy !== assumptions.occupancy) {
      changes.occupancy = editedAssumptions.occupancy;
    }
    if (editedAssumptions.state !== assumptions.state) {
      changes.state = editedAssumptions.state;
    }
    if (editedAssumptions.county !== assumptions.county) {
      changes.county = editedAssumptions.county;
    }
    if (editedAssumptions.horizonYears !== assumptions.horizonYears) {
      changes.horizonYears = editedAssumptions.horizonYears;
    }
    if (editedAssumptions.propertyValue !== assumptions.propertyValue) {
      changes.propertyValue = editedAssumptions.propertyValue;
    }

    reanalyzeMutation.mutate(changes);
  };

  const chipData = [
    { label: "Credit", value: assumptions.creditBand, key: "creditBand" },
    { label: "LTV", value: `${assumptions.ltv.toFixed(1)}%`, key: "ltv" },
    { label: "Occupancy", value: assumptions.occupancy, key: "occupancy" },
    { label: "Location", value: `${assumptions.state}, ${assumptions.county}`, key: "location" },
    { label: "Time Horizon", value: `${assumptions.horizonYears} years`, key: "horizonYears" },
  ];

  return (
    <Card className="border border-border">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <i className="fas fa-sliders-h text-primary mr-2"></i>
          Analysis Assumptions
          <span className="ml-2 text-xs text-muted-foreground">(click to edit)</span>
        </h3>
        
        <div className="flex flex-wrap gap-3">
          {chipData.map((chip) => (
            <Button
              key={chip.key}
              variant="secondary"
              size="sm"
              className="rounded-full"
              data-testid={`chip-${chip.key}`}
            >
              {chip.label}: {chip.value}
            </Button>
          ))}
          
          <Dialog open={isEditingOpen} onOpenChange={setIsEditingOpen}>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                size="sm" 
                className="rounded-full"
                data-testid="button-edit-assumptions"
              >
                <i className="fas fa-edit mr-2"></i>
                Edit
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Edit Assumptions</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="creditBand">Credit Band</Label>
                  <Select 
                    value={editedAssumptions.creditBand} 
                    onValueChange={(value) => setEditedAssumptions({...editedAssumptions, creditBand: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="680-719">680-719</SelectItem>
                      <SelectItem value="720-759">720-759</SelectItem>
                      <SelectItem value="760-799">760-799</SelectItem>
                      <SelectItem value="800+">800+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="ltv">Loan-to-Value (%)</Label>
                  <Input
                    id="ltv"
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={editedAssumptions.ltv}
                    onChange={(e) => setEditedAssumptions({...editedAssumptions, ltv: parseFloat(e.target.value)})}
                  />
                </div>
                
                <div>
                  <Label htmlFor="occupancy">Occupancy</Label>
                  <Select 
                    value={editedAssumptions.occupancy} 
                    onValueChange={(value) => setEditedAssumptions({...editedAssumptions, occupancy: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="primary">Primary Residence</SelectItem>
                      <SelectItem value="secondary">Secondary Home</SelectItem>
                      <SelectItem value="investment">Investment Property</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="state">State</Label>
                  <Input
                    id="state"
                    value={editedAssumptions.state}
                    onChange={(e) => setEditedAssumptions({...editedAssumptions, state: e.target.value})}
                  />
                </div>
                
                <div>
                  <Label htmlFor="county">County</Label>
                  <Input
                    id="county"
                    value={editedAssumptions.county}
                    onChange={(e) => setEditedAssumptions({...editedAssumptions, county: e.target.value})}
                  />
                </div>
                
                <div>
                  <Label htmlFor="horizonYears">Time Horizon (years)</Label>
                  <Input
                    id="horizonYears"
                    type="number"
                    min="1"
                    max="30"
                    value={editedAssumptions.horizonYears}
                    onChange={(e) => setEditedAssumptions({...editedAssumptions, horizonYears: parseInt(e.target.value)})}
                  />
                </div>
                
                <div>
                  <Label htmlFor="propertyValue">Property Value (optional)</Label>
                  <Input
                    id="propertyValue"
                    type="number"
                    min="0"
                    value={editedAssumptions.propertyValue || ''}
                    onChange={(e) => setEditedAssumptions({...editedAssumptions, propertyValue: e.target.value ? parseFloat(e.target.value) : undefined})}
                    placeholder="Enter property value"
                  />
                </div>
                
                <Button 
                  onClick={handleReanalyze} 
                  className="w-full"
                  disabled={reanalyzeMutation.isPending}
                  data-testid="button-reanalyze"
                >
                  {reanalyzeMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-calculator mr-2"></i>
                      Re-analyze
                    </>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
    </Card>
  );
}
