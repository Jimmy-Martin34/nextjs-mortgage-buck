import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Upload() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStage, setUploadStage] = useState<string>("");

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      setIsUploading(true);
      setUploadProgress(10);
      setUploadStage("Getting upload URL...");

      // Step 1: Get presigned URL
      const presignResponse = await apiRequest('POST', '/api/presign', {
        fileName: file.name,
        fileType: file.type,
        fileSize: file.size,
      });
      const { uploadUrl, fileKey } = await presignResponse.json();

      setUploadProgress(30);
      setUploadStage("Uploading document...");

      // Step 2: Upload to S3
      const uploadResponse = await fetch(uploadUrl, {
        method: 'PUT',
        body: file,
        headers: {
          'Content-Type': file.type,
        },
      });

      if (!uploadResponse.ok) {
        throw new Error('Upload failed');
      }

      setUploadProgress(60);
      setUploadStage("Creating submission...");

      // Step 3: Create submission record
      const submissionResponse = await apiRequest('POST', '/api/submissions', {
        email: 'user@example.com', // TODO: Get from form
        fileKey,
        docType: null, // Will be detected
        state: null,
        county: null,
        lenderName: null,
      });

      const submission = await submissionResponse.json();
      
      setUploadProgress(100);
      setUploadStage("Processing complete!");

      return submission;
    },
    onSuccess: (submission) => {
      setTimeout(() => {
        setLocation(`/results/${submission.id}`);
      }, 1000);
      
      toast({
        title: "Upload Successful",
        description: "Your document is being analyzed...",
      });
    },
    onError: (error) => {
      setIsUploading(false);
      setUploadProgress(0);
      setUploadStage("");
      
      toast({
        title: "Upload Failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast({
        title: "Invalid File Type",
        description: "Please upload a PDF file",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please upload a file smaller than 10MB",
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate(file);
  }, [uploadMutation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
    },
    multiple: false,
    disabled: isUploading,
  });

  return (
    <div>
      <Card 
        className={`border-2 border-dashed transition-colors ${
          isDragActive ? 'border-primary/50 bg-primary/5' : 'border-border'
        } ${isUploading ? 'opacity-75' : 'hover:border-primary/50'}`}
        data-testid="upload-area"
      >
        <CardContent className="p-8">
          <div {...getRootProps()} className="text-center cursor-pointer">
            <input {...getInputProps()} data-testid="file-input" />
            
            <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <i className="fas fa-cloud-upload-alt text-primary text-2xl"></i>
            </div>
            
            <h3 className="text-xl font-semibold mb-2">Upload Your Document</h3>
            <p className="text-muted-foreground mb-6">
              {isDragActive 
                ? "Drop your PDF here..."
                : "Drag and drop your Loan Estimate (LE) or Closing Disclosure (CD) here, or click to browse"
              }
            </p>
            
            {!isUploading && (
              <Button 
                className="mb-4"
                data-testid="button-choose-file"
              >
                Choose File
              </Button>
            )}
            
            <div className="text-xs text-muted-foreground">
              <p>Supported: PDF files only • Max size: 10MB</p>
              <p className="mt-1">Your document is processed securely and not stored permanently</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upload Progress */}
      {isUploading && (
        <Card className="mt-6">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Analyzing your document...</span>
              <span className="text-sm text-muted-foreground">{Math.round(uploadProgress)}%</span>
            </div>
            <Progress value={uploadProgress} className="mb-2" />
            <div className="text-xs text-muted-foreground">
              {uploadProgress >= 10 && (
                <div className="flex items-center">
                  <i className="fas fa-check text-success mr-2"></i>
                  Document uploaded successfully
                </div>
              )}
              {uploadProgress >= 30 && (
                <div className="flex items-center">
                  <i className="fas fa-check text-success mr-2"></i>
                  Extracting loan terms and fees...
                </div>
              )}
              {uploadProgress >= 60 && (
                <div className="flex items-center">
                  <i className="fas fa-spinner fa-spin text-primary mr-2"></i>
                  Calculating savings opportunities
                </div>
              )}
              {uploadProgress === 100 && (
                <div className="flex items-center">
                  <i className="fas fa-check text-success mr-2"></i>
                  Analysis complete!
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
