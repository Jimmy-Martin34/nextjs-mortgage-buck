import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface ResultsDisplayProps {
  verdict: {
    monthlyOverpay: number;
    fiveYearSavings: number;
    confidence: number;
  };
}

export default function ResultsDisplay({ verdict }: ResultsDisplayProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return "text-success";
    if (confidence >= 0.6) return "text-warning";
    return "text-destructive";
  };

  return (
    <Card className="shadow-lg border border-border mb-8">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div className="mb-4 md:mb-0">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
              {verdict.monthlyOverpay > 0 ? (
                <>
                  You're likely overpaying <span className="text-destructive">{formatCurrency(verdict.monthlyOverpay)}/month</span>
                </>
              ) : (
                <span className="text-success">Your loan terms look competitive!</span>
              )}
            </h1>
            <p className="text-muted-foreground">
              {verdict.fiveYearSavings > 0 ? (
                <>
                  Potential savings over 5 years: <span className="font-semibold text-success">{formatCurrency(verdict.fiveYearSavings)}</span>
                </>
              ) : (
                "No significant savings opportunities identified"
              )}
              <Badge 
                variant="outline" 
                className={`ml-2 ${getConfidenceColor(verdict.confidence)}`}
              >
                {Math.round(verdict.confidence * 100)}% confidence
              </Badge>
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => window.print()}
              data-testid="button-save-analysis"
            >
              <i className="fas fa-download mr-2"></i>
              Save Analysis
            </Button>
            <Button 
              variant="outline"
              onClick={() => window.location.href = '/'}
              data-testid="button-new-analysis"
            >
              New Analysis
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
