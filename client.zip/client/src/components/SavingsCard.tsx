import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface SavingsCardProps {
  savings: {
    id: string;
    title: string;
    description: string;
    type: string;
    impact: {
      monthlyAmount: number;
      totalAmount: number;
      isOneTime: boolean;
    };
    details: any;
    rationale: string;
    script: string;
    priority: 'high' | 'medium' | 'low';
  };
}

export default function SavingsCard({ savings }: SavingsCardProps) {
  const { toast } = useToast();
  const [isScriptOpen, setIsScriptOpen] = useState(false);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getIcon = (type: string) => {
    const icons: { [key: string]: string } = {
      rate_reprice: "fas fa-percentage",
      points_optimization: "fas fa-coins",
      fee_reduction: "fas fa-receipt",
      title_shopping: "fas fa-file-signature",
      mi_optimization: "fas fa-shield-alt",
    };
    return icons[type] || "fas fa-dollar-sign";
  };

  const getIconColor = (priority: string) => {
    const colors: { [key: string]: string } = {
      high: "text-destructive",
      medium: "text-warning",
      low: "text-success",
    };
    return colors[priority] || "text-primary";
  };

  const copyScript = async () => {
    try {
      await navigator.clipboard.writeText(savings.script);
      toast({
        title: "Script Copied!",
        description: "The negotiation script has been copied to your clipboard.",
      });
      setIsScriptOpen(false);
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Please manually copy the script text.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 bg-${savings.priority === 'high' ? 'destructive' : savings.priority === 'medium' ? 'warning' : 'success'}/10 rounded-lg flex items-center justify-center`}>
              <i className={`${getIcon(savings.type)} ${getIconColor(savings.priority)} text-lg`}></i>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">{savings.title}</h3>
              <p className="text-sm text-muted-foreground">{savings.description}</p>
            </div>
          </div>
          <div className="text-right">
            <div className={`text-2xl font-bold ${getIconColor(savings.priority)}`}>
              {savings.impact.isOneTime ? 
                formatCurrency(savings.impact.totalAmount) :
                `${formatCurrency(savings.impact.monthlyAmount)}/mo`
              }
            </div>
            {!savings.impact.isOneTime && (
              <div className="text-sm text-muted-foreground">
                {formatCurrency(savings.impact.totalAmount)} over 5 years
              </div>
            )}
            {savings.impact.isOneTime && (
              <div className="text-sm text-muted-foreground">One-time savings</div>
            )}
          </div>
        </div>
        
        <div className="bg-muted rounded-lg p-4 mb-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            {Object.entries(savings.details.current).map(([key, value]) => (
              <div key={`current-${key}`}>
                <span className="text-muted-foreground capitalize">{key.replace(/([A-Z])/g, ' $1')}:</span>
                <div className="font-semibold">
                  {typeof value === 'number' && key.includes('rate') ? `${value}%` :
                   typeof value === 'number' && key.includes('amount') ? formatCurrency(value) :
                   String(value)}
                </div>
              </div>
            ))}
            {Object.entries(savings.details.target).map(([key, value]) => (
              <div key={`target-${key}`}>
                <span className="text-muted-foreground capitalize">Target {key.replace(/([A-Z])/g, ' $1')}:</span>
                <div className="font-semibold text-success">
                  {typeof value === 'number' && key.includes('rate') ? `${value}%` :
                   typeof value === 'number' && key.includes('amount') ? formatCurrency(value) :
                   String(value)}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <p className="text-sm text-muted-foreground mb-4">
          {savings.rationale}
        </p>
        
        <Dialog open={isScriptOpen} onOpenChange={setIsScriptOpen}>
          <DialogTrigger asChild>
            <Button 
              className="w-full"
              data-testid={`button-copy-script-${savings.id}`}
            >
              <i className="fas fa-copy mr-2"></i>
              Copy Negotiation Script
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Negotiation Script - {savings.title}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-muted rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-2">Email Script</h4>
                <div className="text-sm text-muted-foreground mb-3">Copy and paste this email to your loan officer:</div>
                
                <div className="bg-background rounded-lg p-4 border border-border font-mono text-sm whitespace-pre-wrap">
                  {savings.script}
                </div>
              </div>
              
              <div className="flex gap-3">
                <Button 
                  onClick={copyScript}
                  className="flex-1"
                  data-testid={`button-copy-to-clipboard-${savings.id}`}
                >
                  <i className="fas fa-copy mr-2"></i>
                  Copy to Clipboard
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => {
                    const subject = encodeURIComponent(savings.script.split('\n')[0].replace('Subject: ', ''));
                    const body = encodeURIComponent(savings.script.split('\n').slice(1).join('\n'));
                    window.open(`mailto:?subject=${subject}&body=${body}`);
                  }}
                >
                  <i className="fas fa-envelope mr-2"></i>
                  Email
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
