import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useToast } from "./use-toast";

export function useSubmission(submissionId?: string) {
  return useQuery({
    queryKey: ['/api/submissions', submissionId],
    queryFn: () => api.getSubmission(submissionId!),
    enabled: !!submissionId,
  });
}

export function useAnalysis(submissionId?: string) {
  return useQuery({
    queryKey: ['/api/analyze', submissionId],
    queryFn: () => api.getAnalysis(submissionId!),
    enabled: !!submissionId,
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
}

export function useReanalyze(submissionId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (overrides: any) => api.analyzeSubmission(submissionId, overrides),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/analyze', submissionId] });
      toast({
        title: "Analysis Updated",
        description: "Your savings analysis has been recalculated.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update analysis. Please try again.",
        variant: "destructive",
      });
    },
  });
}

export function useUpload() {
  const { toast } = useToast();

  return useMutation({
    mutationFn: ({ file, email }: { file: File; email?: string }) => 
      api.uploadFile(file, email),
    onSuccess: () => {
      toast({
        title: "Upload Successful",
        description: "Your document is being analyzed...",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Upload Failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });
}

export function useSubmissions() {
  return useQuery({
    queryKey: ['/api/submissions'],
    queryFn: () => api.listSubmissions(),
    enabled: !!localStorage.getItem('adminToken'),
  });
}

export function useAdminStats() {
  return useQuery({
    queryKey: ['/api/admin/stats'],
    queryFn: () => api.getAdminStats(),
    enabled: !!localStorage.getItem('adminToken'),
  });
}

export function useChat(submissionId: string) {
  const { toast } = useToast();

  return useMutation({
    mutationFn: (message: string) => api.sendChatMessage(submissionId, message),
    onError: () => {
      toast({
        title: "Chat Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });
}
